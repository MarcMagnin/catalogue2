(function () {
  'use strict';
  $.fn.masonry = sinon.spy();
}());
