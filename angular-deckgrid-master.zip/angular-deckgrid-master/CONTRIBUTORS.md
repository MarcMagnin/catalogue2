# angular-deckgrid - contributors

_(ordered by first contribution)_

- [Ben Ma](http://github.com/benjaminma)
- [Mike](http://github.com/mikenikles)
- [Mladen Danic ](http://github.com/Maidomax)
- [Patrick Stapleton](http://github.com/gdi2290)
- [johnwest80](http://github.com/johnwest80)
- [Sebastian Oergel](http://github.com/sebastianoe)
- [Benchekroune](https://github.com/overben)
- [Elad Ossadon](https://github.com/elado)
- [Andrei Malyshev](https://github.com/k41n)